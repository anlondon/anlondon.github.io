title: fastCGI 意外退出
author: anlondon
tags: []
categories:
  - PHP
date: 2021-03-07 18:38:00
---
## 问题

系 统：Windows server 2008
服务器：IIS7
php 5.5

来自anlondon博客
![](http://anlondon.cn:4000/2021/01/29/fastCGI-%E6%84%8F%E5%A4%96%E9%80%80/pasted-2.png)

## 解决
#### 情况一：程序导致的问题

查询资料时，iis7自身是集成了php_pdo.dll的，同时查看服务器其他的项目，都运行正常，说明可能是项目本身的原因，加之iis7与fast-cgi是单线程

于是重启服务器(开关机的那种)，访问项目其他页面，发现访问正常，只有首页**加载很慢且加载不全**，查看页面代码，发现因为客户修改后台数据导致程序中出现了一个**死循环**；

修改相应的代码，解决。

#### 情况二：缺失相关文件

**在iis服务器除了php_pdo外**

进入服务器,查看资源管理器，右键`php-cgi.exe`->所在位置

来自anlondon博客
[](http://anlondon.cn:4000/2021/01/29/fastCGI-%E6%84%8F%E5%A4%96%E9%80%80/pasted-0.png)

双击php.exe、php-cgi.php,出现下面的提示

来自anlondon博客
[](http://anlondon.cn:4000/2021/01/29/fastCGI-%E6%84%8F%E5%A4%96%E9%80%80/pasted-1.png)

去下载对应版本的php_xxx.dll即可。

---
**相关资料**:

- [php_pdo.dll下载并配置|脚本之家](https://www.jb51.net/dll/php_pdo.dll.html)
- [64位IIS7下的PHP 5.4配置及如何连接SQL Server 2008](https://blog.csdn.net/yuweiqing120/article/details/44096721)
- [“php-cgi.exe - FastCGI 进程意外退出” 的解决办法 |CSDN ltylove2007](https://blog.csdn.net/ltylove2007/article/details/55098535)
- [php pdo drivers won’t load on Windows Server 2008 using IIS Fast-CGI](https://forums.iis.net/t/1221836.aspx?php+pdo+drivers+won+t+load+on+Windows+Server+2008+using+IIS+Fast+CGI)
- [Getting Microsoft PHP PDO for SQL Server working |stackOverflow](https://stackoverflow.com/questions/9954623/getting-microsoft-php-pdo-for-sql-server-working)