title: MySQL数据库崩溃
author: anlondon
tags: []
categories:
  - MySql
date: 2021-03-07 21:55:00
---
## 错误：

某台服务器下的网站能访问，但是**所有**的网站**数据库都不能连接**

使用PHPmyadmin 提示
`#2003 无法登录 MySQL 服务器`

> ERROR 2003(HYO00):Can’t connect to MySQL server on ‘localhost’(10061)

## 原因：
数据库崩溃

## 解决：
- **重启数据库**
 1. win：cmd中；(在没有数据库管理软件，且不愿意重启服务器时)
   ```shell
   输入 tasklist | findstr mysql 查看进程状态
   输入 net start mysql 启动进程
   net stop mysql  结束进程
   ```
   > 若提示服务名无效，在`MySql/bin/`目录，执行命令：`mysqld -install` 即可
   > 卸载同上 `mysqld --remove` mysql
 2. Linux：
   ```shell
   systemctl status mysql        查看进程状态
   systemctl restart mysql        重启
   systemctl stop mysql           停止
   systemctl start mysql           启动
   ```
 2. 或者**重启服务器**(开关机的那种，前提是，各项服务设置过开机启动)
 
---
**相关资料**：
- [windows下Mysql安装启动及常用操作](https://www.cnblogs.com/wanggang2016/p/10425780.html)