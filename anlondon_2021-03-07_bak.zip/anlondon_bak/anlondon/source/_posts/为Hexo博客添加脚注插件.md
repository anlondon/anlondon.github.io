title: 为Hexo博客添加脚注插件
author: anlondon
tags: []
categories:
  - Hexo
date: 2021-03-07 11:44:00
---
#### hexo自带的插件
`npm install hexo-reference --save`

> 语法
> \[^1\][^1]
> \[^1\]:内容

〔如用了pm2来管理hexo server，需要完全关闭进程后再运行，才能生效〕


[^1]: 该插件为hexo原生的脚注插件，不需要任何配置，安装重启服务器即可用

#### 其他

来源：[大专栏|为Hexo博客添加脚注插件](https://www.dazhuanlan.com/2019/11/22/5dd6faa42d279/?__cf_chl_jschl_tk__=e728473b2ba8f93d473b0b22cabd71338ea68bcc-1611503290-0-AemEF6yj-Z2HSljjzMFHGYDhyC38unQY8EKhJRLJcUZXDciwsq23hlSxmX5QwjCIxNLn282LG5zc-_BWkbuA7-57iuwqIJKl8wTFUnrtj1Ut7r8Km2L1nXaeguohabL0tobl9BRqOG_0RmsgtgrWHEWxx_u1XUFB57btGcFMl9PTkbdahC6jNwmExpeFsOB7bnZ4lHchZQ0egyIZvrC2KwLsDXagBVcoxEShYlExjt1xk9L5IZnKBzXr8IJ21SWtZQzd7Y6BaDxt2z2F4MsisxL1_hSqibGjZslOOTYAPco1kkKAH3CuE2QziiPbswspxgmtkpZhFdt8weVizqZWKOA#bib1)

注意： 文中涉及的markdown插件需要单独安装
```shell
plugins:
    - markdown-it-abbr
    - markdown-it-footnote
    - markdown-it-ins
    - markdown-it-sub
    - markdown-it-sup
```
上面的所有插件都要安装
`npm i markdown-it-abbr markdown-it-footnote markdown-it-ins markdown-it-sub markdown-it-sup --save`
之后重启服务器即可生效

注：以上的插件，都对base64支持不够，会导致页面不能正确的加载base64图片
