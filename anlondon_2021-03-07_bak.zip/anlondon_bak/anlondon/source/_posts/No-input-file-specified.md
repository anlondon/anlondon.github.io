title: No input file specified
author: anlondon
tags: []
categories:
  - Apache
date: 2021-03-07 21:13:00
---
##### nginx
[解决NGINX PHP “No input file specified”](https://blog.51cto.com/xiahongyuan/852424)

##### apache
[no input file specified 三种解决方法](https://blog.csdn.net/wanganji5252/article/details/81782074)
打开.htaccess 在RewriteRule 后面的index.php教程后面添加一个“?”

完整代码如下

```shell
# /www.xx.com/.htaccess
 
RewriteEngine on
RewriteCond %{Request_FILENAME} !-f
RewriteCond $1 !^(index.php|images|robots.txt)
RewriteRule ^(.*)$ /index.php?/$1 [L]
```

如果是apache服务器出问题，看看是不是的Apache 把 .php 后缀的文件解析哪里有问题了。

总结

Apache 将哪些后缀作为 PHP 解析。例如，让 Apache 把 .php 后缀的文件解析为PHP。可以将任何后缀的文件解析为 PHP，只要在以下语句中加入并用空格分开。这里以添加一个 .phtml 来示例。

`AddType application/x-httpd-php .php .phtml`

为了将 .phps教程作为 PHP 的源文件进行语法高亮显示，还可以加上：

`AddType application/x-httpd-php-source .phps`

用通常的过程启动 Apache(必须完全停止 Apache 再重新启动，而不是用 HUP 或者USR1 信号使 Apache 重新加载)。