#!/usr/bin/env sh
hexo clean
hexo d -d
