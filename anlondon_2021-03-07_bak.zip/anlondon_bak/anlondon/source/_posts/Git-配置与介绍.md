title: Git 配置与介绍
author: anlondon
tags: []
categories:
  - Git
date: 2021-03-07 17:58:00
---
# Github
# 一、安装配置

+ 安装 
    * 访问网址 [Git-download](https://git-scm.com/download)
    * linux [Git-linux](https://git-scm.com/download/linux)
        -  `# yum install git` (up to Fedora 21)
        -  `# dnf install git`(Fedora 22 and later)
+ 配置
    * 第一次使用需要进行用户配置
        * `# git config --global user.name "username"`(不支持中文)
        * `# git config --global user.email "useremail"`
        * 查看配置结果`# git config --list`


# 二、认识Git

+ git记录的是什么

    >  * ![431e79f8.png]传统的版本控制器如svn工作原理，则是记录文件的每次改动
    
    >  * ![6c92b049.png]Git则是每个版本都保存一次，形成一个分支
    >  * 普通的程序员是把很多时间放在写代码和调bug上，而优秀的程序员是将更多的经历放在设计上。
  
  
  
+ git的工作流程
    * git流程
        1. 本地：在工作目录中添加、修改文件
        2. 暂存区-本地：将需要进行版本管理的文件放入暂存区
        3. 提交：将暂存区的文件提交到Git仓库
    * git管理文件的三种状态
        * 已修改 (modified)
        * 已暂存 (staged)
        * 已提交 (committed)
    + ![8f8a0fbb.png]



# 三、使用
+ **Git -生成 -添加 -提交**
    * `# git init`即可在当前项目中生成一个.git目录
    * `# git add README.md` 文件添加到暂存区(本地必须存在该文件)。文件编码：`utf-8notBOM`
    * `# git commit -m "add a readme file"`提交文件到仓库，""中为本次提交说明信息[^1]
    * `# git log` 查看历史提交记录,从近到远排序，commit后为提交的唯一hashId Author提交作者，Date提交时间，以及提交说明 

+ **Git -查看状态**
    * `# git status` 查看git状态，出现的提示[^2]
    * 文件的两种状态[^3]

+ **Git -取消暂存**
    * `# git reset HEAD <file>...` 取消还未提交文件的暂存状态，不指定文件则将当前所有暂存状态文件全部取消暂存状态


+ **Git -取消修改**
    * **[!]** `# git checkout -- <file>` 将仓库最近一次提交的file覆盖本地file

+ **Git -查看历史记录**
    * `# git reflog` 查看git历史记录

# 四、Git -reset
![5d67d3bb.png]

+ **GIT -reset**
    * `# git reset HEAD <file>...` 
        * 取消还未提交文件的暂存状态，不指定文件则将当前所有暂存状态文件全部取消暂存状态
        * **仅对暂存区文件有效**
    * `# git reset --mixed HEAD~`
        * `--mixed`默认指令，不加也可
        * 移动HEAD[^4]的指向，将其指向指定的快照[^5](版本)
        * 将HEAD(指针)移动后指向的快照 **回滚到暂存区**，工作目录不受影响
    * `# git reset --soft HEAD~`
        * `--soft`软回滚
        * 移动HEAD的指向，将其指向上一个快照
        * 将指定版本的提交，回滚到暂存区，**相当于撤销指定版本的一次提交**
    * `# git reset --hard HEAD~`
        * `--hard`强制回滚
        * 移动HEAD的指向，将其指向指定的快照
        * 将HEAD指向的快照回滚到暂存区，同时将暂存区的文件还原到工作目录
        * **相当于本地、暂存区完全回滚到指定快照(版本)**
        * <p style="color:red">**会覆盖本地文件，删除版本中没有文的件**</p>
+ **Git -回滚指定快照**
    * `~` 可换成指定Hashid，一般输入Hashid不少于5位即可识别
    * `# git reset Hashid`,**只要知道某版本的Hashid，就可以回滚到暂存区**，如果加上`--hard`,就会直接回滚到工作目录中
+ **Git -回滚个别文件**
    + `# git reset 版本快照 文件名/路径`因为没有HEAD指令，所以不会移动HEAD   
    + ![一座浮岛](/2021/03/07/Git-配置与介/pasted-0.png)
    
[^1]: 如果提交无误，则会返回【create mode 100644 readme.md】,其中100表示文件为普通文件，644表示权限

[^2]: 'on branch master' 表示处于一个分支上；'Untracked files'表示下面红色的文件/文件夹是没有添加到暂存区的；'changes to be committed'表示新添加到暂存区的文件

[^3]: 当一个文件已经被添加到暂存区(HEAD)后，这时再修改该文件，`# git status`就会看到该文件的两种状态，一个未提交到仓库(绿色)，一个未添加到暂存区。

[^4]: 这里的HEAD表示指针，表示指向某个分支。HEAD~表示指向上一个分支，**并覆盖本地文件**HEAD~~表示回退2个版本，也可使用HREAD~2表示

[^5]: 每一个版本称为一个快照