title: 建立局域网git仓库
author: anlondon
tags: []
categories:
  - Git
date: 2021-03-07 11:41:00
---
#### 建立本地git仓库并共享

1. 新建一个文件夹，路径不要太长，最好是硬盘下的一级文件夹
2. 使用`git init --bare`建立一个仓库，该指令表示建立一个 独立的仓库 使用git init --bare建立一个本地裸仓库
3. 共享该目录，添加guest访客并给予读写权限
   - 右键该目录->属性->共享->高级共享，勾选共享此文件夹
   - 点击权限->给Everyone完全控制的权限->点击确定->点击应用
    来自anlondon博客
    来自anlondon博客    
4. 进入一个本地的项目，并且提交到本地仓库中
    来自anlondon博客
5. 使用ipconfig查看本机的局域网ip,格式为 192.168.0.xxx

#### 在局域网的另一台电脑上拉取项目

1. 进入网络，可以看到共享的仓库
    来自anlondon博客
2. `git clone //192.168.0.xxx/test.git`或者`git pull //192.168.0.xxx`来拉取项目
    来自anlondon博客
