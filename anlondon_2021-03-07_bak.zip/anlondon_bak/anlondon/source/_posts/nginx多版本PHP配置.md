title: nginx多版本PHP配置
author: anlondon
tags: []
categories:
  - Nginx
date: 2021-03-07 20:50:00
---
参考NGINX配置手册 [Nginx中文文档|虚拟主机](https://www.nginx.cn/doc/example/virtualhost.html)

有讲解到 UNIX Domain Socket 和 tcp 的区别
[nginx: fastcgi_pass的配置](https://segmentfault.com/a/1190000021134764)

视频讲解：[【体验课】NGINX快速学习指南](https://www.bilibili.com/video/BV11f4y1z7K9?t=72&p=7)

### nginx多版本PHP配置

一位客户服务器配置为

- CentOS7
- PHP 7.4
- mysql 5.7
- NGINX 1.15.11

但是因为项目只能使用PHP5.x，因此需要修改相应的服务器配置

##### 安装 nginx
[nginx 官网](http://nginx.org/)

1. 安装依赖包:
`# yum -y install pcre pcre-devel openssl openssl-devel gcc gcc-c++ autoconf automake zlib-devel libxml2 libxml2-dev libxslt-devel gd-devel perl-devel perl-ExtUtils-Embed GeoIP GeoIP-devel GeoIP-data make  GeoIP-devel GeoIP-update`

2. 下载nginx1.15
```shell
$ cd /usr/local/src/
$ curl -o nginx-1.15.1.tar.gz http://nginx.org/download/nginx-1.15.1.tar.gz
```

3. 创建用户和组
```shell
# groupadd nginx
# useradd nginx -g nginx -s /sbin/nologin -M
```

4. 解压,配置,编译,安装
官网对参数的说明
[Building nginx from Sources](http://nginx.org/en/docs/configure.html)
```shell
$ tar -zxvf nginx-1.15.1.tar.gz
$ cd nginx-1.15.1

#测试一下
$ ./configure
#如果没报错则开始设置

#设置
$ ./configure --prefix=/usr/local/nginx --user=nginx --conf-path=/usr/local/nginx/nginx.conf --pid-path=/usr/local/nginx/nginx.pid --error-log-path=/usr/local/nginx/logs/error.log --http-log-path=/usr/local/nginx/logs/access.log --group=nginx --with-http_ssl_module --with-http_realip_module --with-http_geoip_module --with-http_stub_status_module --with-http_sub_module --with-stream --with-stream=dynamic 

#编译安装
$ make && make install
```

> 安装出现的一些错误以及解决办法
> 1. [Linux Nginx安装以及可能出现错误](https://blog.csdn.net/sanchan/article/details/51213382)
> 2. [Error: xz compression not available的解决办法](http://blog.sina.com.cn/s/blog_4988d99a0102x9yk.html)
> 3. 如果不指定 nginx.pid 路径，则运行时可能报错
>  - `./nginx` 启动，重启 nginx 时**遇到错误会直接停止 nginx**,并**删除pid文件**，此时<u>解决报错，并启动 nginx 即可</u>。
>  - [解决Nginx: error open() ＂/usr/local/Nginx/logs/Nginx.pid” failed（2:No such file or directory）](https://www.cnblogs.com/iloverain/p/9428630.html)

5. 添加为系统服务，新建一个服务
`$ vim /usr/lib/systemd/system/nginx.service`

复制下面的内容，路径改为自己设置的路径

```shell
[Unit]
Description=nginx
After=network.target

[Service]
Type=forking
PIDFile=/usr/local/nginx/logs/nginx.pid
ExecStartPre=/usr/local/nginx/sbin/nginx -t -q -g 'daemon on; master_process on;'
ExecStart=/usr/local/nginx/sbin/nginx -g 'daemon on; master_process on;'
ExecReload=/usr/local/nginx/sbin/nginx -g 'daemon on; master_process on;' -s reload
ExecStop=-/sbin/start-stop-daemon --quiet --stop --retry QUIT/5 --pidfile /usr/local/nginx/logs/nginx.pid
TimeoutStopSec=5
KillMode=mixed

[Install]
WantedBy=multi-user.target
```

```shell
#设置nginx.service文件的权限
$ chmod 664 /usr/lib/systemd/system/nginx.service

#验证服务
$ curl -I 127.0.0.1:80
```

6. nginx命令行参数：
```shell
#nginx 原生参数
	-V    查看编译参数。
	-h    查看帮助。
	-g    设置全局配置指令。
	-s    发送信号
              信号:
		   stop   快速关闭
		   quit   正常关闭，等待工作进程完成当前请求后停止nginx进程
		   reload 重新加载配置文件
		   reopen 重新打开日志文件.
#使用 ./nginx -s stop/quit/reload/reopen

#系统服务指令
$ systemctl status nginx.service
$ systemctl start nginx.service
$ systemctl restart nginx.service
$ systemctl stop nginx.service

#开启服务启动时执行
$ systemctl enable nginx.service
```

##### 配置 nginx 虚拟机使用指定版本PHP
`# vim /usr/local/nginx/nginx.conf`

```shell
server{
	listen 80;
    server_name localhost;
    root /usr/local/nginx/html/guoxinan/;
    location / {
		index index.php index.html;
        autoindex off;
    }
    
	location ~ \.php$ {
    	#监听指定php版本的 cgi 端口
		fastcgi_pass 127.0.0.1：9074;
        fastcgi_param SCRIPT FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
	}
}
```

在 `http{}` 中，一个 `server{}` 表示一个虚拟机，而虚拟机使用 指定版本 PHP 也只需要设置

```shell
location ~ \.php$ {
   	#监听指定php版本的 cgi 端口
	fastcgi_pass 127.0.0.1：9074;
       fastcgi_param SCRIPT FILENAME $document_root$fastcgi_script_name;
       include fastcgi_params;
}
```
![一座浮岛](/2021/03/07/nginx多版本PHP配/pasted-1.png)

##### 伪静态
[nginx常用伪静态设置](https://www.cnblogs.com/steven9898/p/11331138.html)
[Nginx针对URL或目录访问控制总结](https://blog.mydns.vip/2546.html)

[nginx多版本PHP配置](https://www.cnblogs.com/lty-fly/p/12581698.html)

**引用**
项目根目录下的 nginx.htaccess 文件
`include /xx/WWW/xxx/nginx.htaccess;`

**伪静态规则**
允许某些目录下的文件访问
```shell
if ($request_filename !~* /(index\.php|htsysadmin|HTSYSADMIN|Bak2010|robots\.txt|favicon\.ico|sitemap\.xml|sitemap\.html|skin|upload)) {
      rewrite ^/(.*)$ /index.php/$1 last;
}
```

```shell
-e filename 如果 filename存在，则为真
-d filename 如果 filename为目录，则为真 
-f filename 如果 filename为常规文件，则为真
-L filename 如果 filename为符号链接，则为真
-r filename 如果 filename可读，则为真 
-w filename 如果 filename可写，则为真 
-x filename 如果 filename可执行，则为真
-s filename 如果文件长度不为0，则为真
-h filename 如果文件是软链接，则为
```

---
**相关资料**:
- [nginx1.15安装(一)](https://blog.51cto.com/liyuanjie/2151738)
- [nginx1.15安装和配置](https://blog.csdn.net/liberalliushahe/article/details/89736311)
- [Error: xz compression not available的解决办法](http://blog.sina.com.cn/s/blog_4988d99a0102x9yk.html)
- [RHEL/CentOS 7中Nginx的systemd service](https://blog.csdn.net/taiyangdao/article/details/90613947)
- [【部署问题】解决Nginx: [error] open() ＂/usr/local/Nginx/logs/Nginx.pid” failed（2:No such file or directory）](https://www.cnblogs.com/iloverain/p/9428630.html)
- [解决NGINX PHP “No input file specified”](https://blog.51cto.com/xiahongyuan/852424)
- [$request_filename + nginx内置变量](https://www.cnblogs.com/infy/p/8550282.html)
