title: apache 无法读取index.html
author: anlondon
tags: []
categories:
  - Apache
date: 2021-03-07 19:22:00
---
### 问题

在测试一个功能时，建立子站，里面全是静态文件，使用 Apache 链接到该项目目录，访问时，却提示 **500 Internal Server Error**

检查 Apache 配置文件，并没有问题，在 URL 链接后加上 index.html 就能正常访问

### 解决

在 stackoverflow 看到相似的问题[.htaccess DirectoryIndex不起作用](https://stackoverflow.com/questions/10212778/htaccess-directoryindex-does-not-work)，其中一位老哥的回答

> You have to check if there is any htaccess rule on parent directory that conflics with this rule, my problem was that, having a RewriteEngine on root directory and “/folder/“ DirectoryIndex won’t work.
>
> 您必须检查在父目录上是否有任何htaccess规则与此规则相冲突，我的问题是，在根目录和“ / folder /” DirectoryIndex上具有RewriteEngine将不起作用。

1. 修改父级 .htaccess
 在 `RewriteCond` 中添加 子站的目录`html`
 添加前:
 `
 RewriteCond $1  !^(index\.php|image|robots\.txt|favicon\.ico)
 `
 添加后:
 `RewriteCond $1 !^(index\.php|image|robots\.txt|favicon\.ico|html)`

2. 子站根目录下 添加首页访问规则
 在子站 `html` 根目录下新建 `.htaccess` ,输入以下内容
 `DirectoryIndex index.html index.htm`
3. 查看 Apache 是否开启重写
 找到 Apache 软件所在目录

 - 如果你是单个网站，且没有添加过网站对应的 .conf 文件
  > 编辑 apache/conf/httpd.conf ，修改AllowOverride None 为 AllowOverride All

  - 如果有多个网站，且每个网站都有对应的 .conf 文件,如我当前项目的为test,端口为80，则网站配置文件为test_80.conf
  > 编辑 `apache/conf/vhosts/test_80.conf` ,修改`AllowOverride None` 为 `AllowOverride All`,没有则添加

---
**相关资料**:
- [.htaccess DirectoryIndex不起作用 |stackoverflow](https://stackoverflow.com/questions/10212778/htaccess-directoryindex-does-not-work)
- [Apache Core Features](http://httpd.apache.org/docs/current/mod/core.html#allowoverride)