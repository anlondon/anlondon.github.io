title: xdebug断掉调试经常无故断开
author: anlondon
tags: []
categories:
  - PHP
date: 2021-03-07 19:20:00
---
需要在vhost.conf中加上两行
```shell
    IPCConnectTimeout 3000
    IPCCommTimeout 3000
```

```shell
<VirtualHost *:80>
	DocumentRoot "D:/phpstudy_pro/WWW/login"
	ServerName www.1688.net
	ServerAlias
    FcgidInitialEnv PHPRC "D:/phpstudy_pro/Extensions/php/php-5.6.27-nts"
    AddHandler fcgid-script .php
    
#加入以下两行
    IPCConnectTimeout 3000
    IPCCommTimeout 3000
#end 

    FcgidWrapper "D:/phpstudy_pro/Extensions/php/php-5.6.27-nts/php-cgi.exe" .php
    <Directory "D:/phpstudy_pro/WWW/login">
    Options FollowSymLinks ExecCGI
    AllowOverride All
    Order allow,deny
    Allow from all
    Require all granted
    DirectoryIndex index.php index.html
    </Directory>
</VirtualHost>
```