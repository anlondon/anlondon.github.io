title: python 批量压缩图片
author: anlondon
tags: []
categories:
  - Python
date: 2021-03-07 21:11:00
---
![](http://anlondon.cn:4000/2021/02/06/python-%E6%89%B9%E9%87%8F%E5%8E%8B%E7%BC%A9%E5%9B%BE/pasted-0.png)

上源码
```python
from PIL import Image
import os
import time


# 获取图片文件的大小
def get_size(file):
    # 获取文件大小:KB
    size = os.path.getsize(file)
    return size / 1024


# 拼接输出文件地址
def get_outfile(infile, outfile):
    if outfile:
        return outfile
    dir, suffix = os.path.splitext(infile)
    #outfile = '{}-out{}'.format(dir, suffix)
    outfile = '{}{}'.format(dir, suffix)
    print(outfile)
    return outfile,suffix


# 压缩文件到指定大小，我期望的是150KB,step和quality可以修改到最合适的数值
def compress_image(infile, outfile='', mb=250, step=10, quality=80):
    """不改变图片尺寸压缩到指定大小
    :param infile: 压缩源文件
    :param outfile: 压缩文件保存地址
    :param mb: 压缩目标，KB
    :param step: 每次调整的压缩比率
    :param quality: 初始压缩比率
    :return: 压缩文件地址，压缩文件大小
    """
    o_size = get_size(infile)
    if o_size <= mb:
        return infile
    outfile,suffix = get_outfile(infile, outfile)
    #if suffix
    while o_size > mb:
        im = Image.open(infile)
        #im = Image.fromarray(infile)
        im.save(outfile, quality=quality)
        #im.convert('RGB').save(outfile, quality=quality)
        if quality - step < 0:
            break
        quality -= step
        o_size = get_size(outfile)
    return outfile, get_size(outfile)



# 修改图片尺寸，如果同时有修改尺寸和大小的需要，可以先修改尺寸，再压缩大小
#x_s=1376
def resize_image(infile, outfile='', x_s=320):
    """修改图片尺寸
    :param infile: 图片源文件
    :param outfile: 重设尺寸文件保存地址
    :param x_s: 设置的宽度
    :return:
    """
    im = Image.open(infile)
    x, y = im.size
    y_s = int(y * x_s / x)
    out = im.resize((x_s, y_s), Image.ANTIALIAS)
    outfile = get_outfile(infile, outfile)
    out.save(outfile)

# 获取文件夹下所有文件
def listdir(path, list_name):  #传入存储的list
    for file in os.listdir(path):
        file_path = os.path.join(path, file)  
        if os.path.isdir(file_path):
            listdir(file_path, list_name)  
        else:
            list_name.append(file_path)



if __name__ == '__main__':
    list = []
    listdir('./1/',list)
    for li in list:
        #print(li)
        compress_image(li)
        #resize_image(li)
        #break
```

---
**相关资料**：
- [总结python处理图片等比例压缩与质量处理的方法](https://blog.csdn.net/xun527/article/details/108789137)