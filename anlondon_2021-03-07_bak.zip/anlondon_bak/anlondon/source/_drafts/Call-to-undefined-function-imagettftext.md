---
title: Call to undefined function imagettftext()
author: anlondon
tags:
---
