title: git-不同版本pull时报错
author: anlondon
tags: []
categories:
  - Git
date: 2021-03-07 12:03:00
---
#### 前提
我在家里弄ci-demo,修改了之后上传到coding,回到公司后，想覆盖公司电脑文件细节不一样的版本

pull时报错
`fatal: refusing to merge unrelated histories`

http://anlondon.cn:4000/2021/01/27/git-%E4%B8%8D%E5%90%8C%E7%89%88%E6%9C%ACpull%E6%97%B6%E6%8A%A5/pasted-1.png

通过[博客](https://blog.csdn.net/qq_39400546/article/details/100150320)的讲解，使用
`git pull origin master --allow-unrelated-histories`
http://anlondon.cn:4000/2021/01/27/git-%E4%B8%8D%E5%90%8C%E7%89%88%E6%9C%ACpull%E6%97%B6%E6%8A%A5/pasted-2.png

http://anlondon.cn:4000/2021/01/27/git-%E4%B8%8D%E5%90%8C%E7%89%88%E6%9C%ACpull%E6%97%B6%E6%8A%A5/pasted-3.png

最后 手动编辑 保留想要的版本即可

http://anlondon.cn:4000/2021/01/27/git-%E4%B8%8D%E5%90%8C%E7%89%88%E6%9C%ACpull%E6%97%B6%E6%8A%A5/pasted-4.png

http://anlondon.cn:4000/2021/01/27/git-%E4%B8%8D%E5%90%8C%E7%89%88%E6%9C%ACpull%E6%97%B6%E6%8A%A5/pasted-5.png