title: >-
  除非Windows Activation
  Service（WAS）和万维网发布服务（W3SVC）均处于运行状态，否则无法启动网站。目前，这两项服务均处于停止状态。
author: anlondon
tags: []
categories:
  - IIS
date: 2021-03-07 21:40:00
---
# 问题

如题，在本地处理一个iis项目时，遇到

> 除非Windows Activation Service（WAS）和万维网发布服务（W3SVC）均处于运行状态，否则无法启动网站。目前，这两项服务均处于停止状态。

![](http://anlondon.cn:4000/2021/02/18/%E9%99%A4%E9%9D%9EWindows-Activation-Service%EF%BC%88WAS%EF%BC%89%E5%92%8C%E4%B8%87%E7%BB%B4%E7%BD%91%E5%8F%91%E5%B8%83%E6%9C%8D%E5%8A%A1%EF%BC%88W3SVC%EF%BC%89%E5%9D%87%E5%A4%84%E4%BA%8E%E8%BF%90%E8%A1%8C%E7%8A%B6%E6%80%81%EF%BC%8C%E5%90%A6%E5%88%99%E6%97%A0%E6%B3%95%E5%90%AF%E5%8A%A8%E7%BD%91%E7%AB%99%E3%80%82%E7%9B%AE%E5%89%8D%EF%BC%8C%E8%BF%99%E4%B8%A4%E9%A1%B9%E6%9C%8D%E5%8A%A1%E5%9D%87%E5%A4%84%E4%BA%8E%E5%81%9C%E6%AD%A2%E7%8A%B6%E6%80%81/pasted-0.png)


# 解决
在**WINDOWS服务管理**里 启动 
- Windows Process Activation Service
- World Wide Web Publishing Service
![](http://anlondon.cn:4000/2021/02/18/%E9%99%A4%E9%9D%9EWindows-Activation-Service%EF%BC%88WAS%EF%BC%89%E5%92%8C%E4%B8%87%E7%BB%B4%E7%BD%91%E5%8F%91%E5%B8%83%E6%9C%8D%E5%8A%A1%EF%BC%88W3SVC%EF%BC%89%E5%9D%87%E5%A4%84%E4%BA%8E%E8%BF%90%E8%A1%8C%E7%8A%B6%E6%80%81%EF%BC%8C%E5%90%A6%E5%88%99%E6%97%A0%E6%B3%95%E5%90%AF%E5%8A%A8%E7%BD%91%E7%AB%99%E3%80%82%E7%9B%AE%E5%89%8D%EF%BC%8C%E8%BF%99%E4%B8%A4%E9%A1%B9%E6%9C%8D%E5%8A%A1%E5%9D%87%E5%A4%84%E4%BA%8E%E5%81%9C%E6%AD%A2%E7%8A%B6%E6%80%81/pasted-1.png)

# 可能遇到的问题
1. 没有IIS
> 见[Windows无法启动 Windows Process Activation Service 服务： 系统找不到指定的路径](http://www.pgygho.com/help/win7/22658.html)

2. 错误1068：依赖服务或组无法启动。
> 右键 -> 属性 -> 依存关系
启动所有列出来的服务

3. 错误3：系统找不到指定的路径。
> 启动 Windows Process Activation Service出现提示：
> `Windows 无法启动Windows Process Activation Service服务（位于本地计算机上）。`
> 依次尝试以下方法：
> 
>  - 在Windows功能中，找到并开启`Windows Process Activation Service`内所有功能 重启。
>  - [没有对应的文件夹](https://blog.csdn.net/tangsilai/article/details/7745786) 手动创建 `c:\inetpub\temp\apppools` 文件夹
>  - [清理注册表](https://www.jianshu.com/p/60e169768b38)

---
**相关资料**：
- [除非 Windows Activation Service (WAS)和万维网发布服务(W3SVC)均处于运行状态，否则无法启动网站。IIS 7]()- [除非 Windows Activation Service (WAS)和万维网发布服务(W3SVC)均处于运行状态，否则无法启动网站。IIS 7](https://www.cnblogs.com/yizl/archive/2011/04/26/2029796.html)
- [Windows无法启动 Windows Process Activation Service 服务： 系统找不到指定的路径](http://www.pgygho.com/help/win7/22658.html)
- [Windows 10更新后Windows Process Activation Service服务不能启动 ](https://answers.microsoft.com/zh-hans/windows/forum/windows_10-other_settings/windows-10%E6%9B%B4%E6%96%B0%E5%90%8Ewindows/ca0bab9a-941e-4066-8a80-71f92469ad1c)
- [Windows Process Activation Service启动失败，显示系统找不到指定路径](https://blog.csdn.net/tangsilai/article/details/7745786)
- [Windows无法启动 Windows Process Activation Service 服务： 系统找不到指定的路径](https://www.jianshu.com/p/60e169768b38)