title: phpstudy mysql启动不了
author: anlondon
tags: []
categories:
  - MySql
date: 2021-03-07 22:11:00
---
# 问题
手动的将 MySQL 服务开启，使MySQL可以通过命令行控制后，phpstudy 就无法启动 mysql了，只能在命令行中控制。

# 解决
暂无解决办法

软件和命令行只能取其一

开启或关闭MySQL服务见[MySQL数据库崩溃](http://anlondon.cn/2021/03/07/MySQL%E6%95%B0%E6%8D%AE%E5%BA%93%E5%B4%A9%E6%BA%83/)