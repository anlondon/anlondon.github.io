title: 缺少 「secure」 cookie 已拒绝 “ci-session”
author: anlondon
tags: []
categories:
  - cookie
date: 2021-03-07 18:27:00
---
## 问题

最近在做公司的一个抽奖活动项目，由于是手机端，所以没有设置cookie的保存时间，即默认cookie为临时会话，当用户关闭浏览器或者关闭网页cookie就会过期。

但是在测试时，明明没有关闭网页和浏览器，刚刚登陆过一会就又跳转到登陆页面，查看浏览器控制台，显示如下信息。
`ci-session` 为后台设置的`cookie_name`

`缺少 「secure」 cookie 已拒绝 “ci-session”`
![来自anlondon博客](http://anlondon.cn:4000/2021/01/29/cookie-%E5%B7%B2%E6%8B%92%E7%BB%9D-%E2%80%9Cci-session/pasted-1.png)

## 解决

在 cookie 设置中，将`$config['cookie_secure']`的值改为`TRUE`，问题解决

---
**相关资料**：

- [Cookie 的 SameSite 属性 |CSDN 我依旧满足于那么的不自信](https://blog.csdn.net/weixin_44269886/article/details/102459425)