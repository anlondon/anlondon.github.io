title: ftp多用户配置
author: anlondon
tags: []
categories:
  - FTP
date: 2021-03-07 19:41:00
---
# 起因
一个客户要求一个文件夹里的不同子目录需要不同的ftp账号进行管理，
例如下面，这是一位客户的要求

```shell
FTP1，不绑定域名，有读写权限，预先建立以下目录结构：
    /bootstrap
    /bootstrap/resources
    /bootstrap/resources/attachment
    /bootstrap/resources/skin

FTP2，绑定域名sso.xxx.com、www.xxx.com、data.xxx.com，
有读写权限；路径为
	/bootstrap

FTP3，绑定域名file.xxx.com，
有读写权限；路径为
	/bootstrap/resources/attachment
    
FTP4，绑定域名skin.xxx.com，有读写权限；
路径为
	/bootstrap/resources/skin

FTP5，绑定域名ress.xxx.com，有读写权限；
路径为
	/bootstrap/resources
```

# 问题

建立多层级目录，和对应的ftp后，发现只有父级目录的ftp账号能链接访问，而子级ftp账号却显示不能链接，

比如使用 FTP1 连接时，可以访问 `/bootstrap` ，但是子级目录却只能看不能进入访问

而使用剩余的账号访问时，直接就**拒绝访问**了。

# 解决

这是因为在建立ftp时，对应的目录的所有者会变为对应的ftp账号，而其他账号会因为没有访问权限而被阻止访问。

例如在建立 FTP1 时，/bootstrap目录的所有者会变为 FTP1 账号。
而建立其他账号时，也相应的改变了对应目录的所有者权限，但是**父级目录的权限却并没有改变**。
所以需要给父级目录分别添加上对应的子级账号**访问控制权限**即可。

- 在父级目录 给 子级账号访问权限 
 ![来自anlondon博客](http://anlondon.cn:4000/2021/02/02/ftp%E5%A4%9A%E7%94%A8%E6%88%B7%E9%85%8D/pasted-0.png)
- 同时也要在子级目录 给 FTP1 访问权限
 ![来自anlondon博客](http://anlondon.cn:4000/2021/02/02/ftp%E5%A4%9A%E7%94%A8%E6%88%B7%E9%85%8D/pasted-1.png)

> 注意：只需要在父级目录修改权限即可，子级目录会自动继承父级栏目的权限设定
