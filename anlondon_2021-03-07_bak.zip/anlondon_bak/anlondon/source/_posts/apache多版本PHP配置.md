title: apache多版本PHP配置
author: anlondon
tags: []
categories:
  - Apache
date: 2021-03-07 21:16:00
---
# 导言
**windows** 用户见[windows - apache 配置多个版本的 php](https://www.cnblogs.com/songlen/p/6613884.html)

因为项目需要，要在 Linux 上使用apache 部署多个 PHP 项目，且 不同项目的要用到不同的 PHP 版本，因此在这里记录下。

- Linux：CentOS7
- Apache：2.4
- PHP : 5.6 需要安装7.4

## 步骤
服务器使用的是阿里云的，里面已经集成了 Apache & PHP5.6，可以直接使用他们配置的文件，这里只需要安装PHP7即可

###### 一、安装PHP7.4
- 访问[php官网下载列表](https://www.php.net/downloads.php)，找到PHP7.4,复制其下载链接。
- 阿里默认PHP安装在 /usr/local/ ,进入该目录，并下载PHP7.4到该目录

```shell
#下载安装包
$ cd /usr/local/
$ wget https://www.php.net/distributions/php-7.4.15.tar.gz

#解压
$ tar -zxvf php-7.4.15.tar.gz

#检查当前的环境是否满足要安装软件的依赖关系
$ cd php-7.4.15
#设置安装目录并编译检查依赖
#可用 ./configure --help 查看当前版本的可选项
#注意参数中有  多个  php设置路径

./configure --prefix=/usr/local/php74 --with-config-file-path=/usr/local/php74 --enable-mysqlnd --with-mysqli=mysqlnd --with-pdo-mysql=mysqlnd --with-iconv-dir --with-freetype --with-jpeg --with-zlib --enable-xml --disable-rpath --enable-bcmath --enable-shmop --enable-sysvsem --enable-inline-optimization --with-curl --enable-mbregex --enable-mbstring --enable-intl --enable-ftp --enable-gd --with-external-gd --with-openssl --with-mhash --enable-pcntl --enable-sockets --with-xmlrpc --enable-soap --with-gettext --disable-fileinfo --enable-opcache --with-sodium --with-webp --enable-fpm
```

> 注意编译时安装路径的设置
上面的参数除了PHP程序的安装路径，还有其配置文件的路径
> 如果路径错误，会导致php无法正常运行，并且难以察觉
> 更多的选项见 `./configure --help`
> [php编译参数注解](https://www.cnblogs.com/hubing/p/3735452.html)(该链接内容仅作参考，以`./configure –help`为准)
> 
> 提示 Package ‘xxxx’, required by ‘virtual:world’, not found
> php 源码安装常见问题汇总
> [Installing Libsodium](https://paragonie.com/book/pecl-libsodium/read/00-intro.md#installing-libsodium)

当**出现下面的界面**，则表示**安装成功**
![一座浮岛](/2021/03/07/apache多版本PHP配/pasted-0.png)

```shell
#测试编译
$ make
$ make test

#(1)如果检查时出现某些依赖没有安装，则需要单独安装，不然会出现
#make: *** No targets specified and no makefile found. Stop
#(2)编译成功后出现某某选项无法识别
#configure: WARNING: unrecognized options:...
#见底部 相关资料

#安装
make install
```

- 配置PHP.ini。 在之前编译的源码包中，找到 php.ini-production，复制到/usr/local/php下，并改名为php.ini
`cp php.ini-production /usr/local/php74/php.ini`

 [cgi]修改配置文件php.ini
 ```shell
 vim /usr/local/php74/php.ini
 #修改
 cgi.fix_pathinfo=0
 ```
 见 [为什么php.ini设置cgi.fix_pathinfo=0](https://blog.csdn.net/weixin_39421014/article/details/80597062)
 
 **[可选项]**设置让PHP错误信息打印在页面上
 ```shell
 $ vim /usr/local/php74/php.ini
 
 display_errors = off
 ```
 将 `Off` 改成 `On`
 
- 配置php-fpm
 ```shell
 #修改php-fpm配置文件：
 $ cd /usr/local/php74/etc
 $ cp php-fpm.conf.default php-fpm.conf
 $ vim php-fpm.conf
 #去掉 pid = run/php-fpm.pid 前面的分号
 #开启错误日志，否则无法运行php-fpm
 #阿里云有配置过日志目录，因此使用 find / -name php-fpm.log 即可找到日志保存目录
 ```
 配置**www.conf**
 ```shell
 $ cd php-fpm.d
 $ cp www.conf.default www.conf

 $ vim www.conf
 #(1)更改侦听端口为9001(9000 为默认端口)
 #(2)修改用户和组为当前用户(默认会添加nobody这个用户和用户组)
 ```
 ![一座浮岛](/2021/03/07/apache多版本PHP配/pasted-1.png)

 ![一座浮岛](/2021/03/07/apache多版本PHP配/pasted-2.png)

- 测试php-fpm是否安装成功
 ```shell
 #启动 php74 内的 php-fpm
/usr/local/php74/sbin/php-fpm

 #看是否有报错，没有任何提示，则说明 fpm 安装配置无误
 ```
 **查看是否启动成功**
 `ps aux|grep php`
 ![一座浮岛](/2021/03/07/apache多版本PHP配/pasted-3.png)
 
- 添加 php-fpm 到系统服务内
 ```shell
 #将 fpm 管理程序放入系统
 $ cp /usr/local/php-7.4.15/sapi/fpm/init.d.php-fpm /etc/init.d/php74-fpm
#添加可执行权限
 $ chmod +x /etc/init.d/php74-fpm
 ```
 
 设置开机启动
 `chkconfig --add /etc/init.d/php74-fpm`
 
 更多命令
 ```shell
 service php74-fpm start #启动
 service php74-fpm restart #重启
 service php74-fpm stop #停止
 ```
 
- php-fpm配置文件参数解释
见 [脚本之家|配置php-fpm参数及配置详解](https://www.jb51.net/article/42716.htm)

**需要注意的地方**
1. `./configure` 编译参数时，使用 `./configure --help`查看**当前版本的编译参数**
2. 编译安装时，设置PHP安装路径有两种方式,见[Linux下指定pip install和make install安装路径](https://www.cnblogs.com/lenmom/p/10189140.html)
3. 并没有找到一个 fpm 管理多个 php 的办法,因此启动多版本PHP需要多个相应的 fpm

###### 配置apache
- 安装mod_fcgid.so,该模块可以支持 apache 运行多版本的 php.

 > 请根据apache版本选择对应版本的mod_fcgid.so，这里以apache2.4为例

 ```shell
 #下载
 $cd /usr/local/src
 $ wget https://mirrors.tuna.tsinghua.edu.cn/apache/httpd/mod_fcgid/mod_fcgid-2.3.9.tar.gz

 #解压安装
 $ tar -zxvf mod_fcgid-2.3.9.tar.gz
 $ cd mod_fcgid-2.3.9

 $ APXS=/usr/local/apache/bin/apxs ./configure.apxs

 $ make
 $ make install
 ```

- 修改httpd.conf , 安装好该模块后，httpd.conf 会自动添加加载该模块。
 ```shell
 #备份httpd.conf
 $ cp /usr/local/apache/httpd.conf /usr/local/apache/httpd.conf.bak

 #编辑设置 mod_fcgi
 $ vim /usr/local/apache/conf/httpd.conf
 #查找是存在mod_fcgid模块
 /mod_fcgid/
 #需要其开启，没有则手动添加 
 LoadModule fcgid_module modules/mod_fcgid.so
 FcgidMaxProcesses 1000 #php-cgi最大的进程数
 MaxRequestLen 52428800 #php程序最大文件上传限制50mb 默认为131072（128kb）

 #读取并运行 php 文件
 #找到AddType application/x-gzip .gz .tgz
 #在该行下面添加
 AddType application/x-httpd-php .php

 #保存退出
 :wq!  
 ```
 
 > apache php fastcgi模式下，默认上传文件大小只有131072字节（128kb），需要在apache的配置文件中修改
 > fastcgi模式下，在php.ini中修改upload_max_filesize等参数无效。

- 配置虚拟机
 ```shell
 $ vim /usr/local/apache/conf/httpd.conf

 #找到 #Include conf/extra/httpd-vhosts.conf,取消注释
#保存退出

 $ vim /usr/local/apache/conf/extra/httpd-vhost.conf
 #里面给出了一个虚拟机配置模板按照该模板配置即可
 ```

 ![一座浮岛](/2021/03/07/apache多版本PHP配/pasted-4.png)
 
 如图，建立了两个虚拟机，并指定了不同的PHP

 访问一下
 ![一座浮岛](/2021/03/07/apache多版本PHP配/pasted-5.png)
 
 再试试另一个
 ![一座浮岛](/2021/03/07/apache多版本PHP配/pasted-6.png)
 
成功

**需要注意的地方**
1. 需要添加 `AddType application/x-httpd-php .php` 才能使解析php文件
2. apache2.4 允许外部访问 参数简化为 `Require all granted`,之前版本为
```shell
AllowOverride All
Order allow,deny
Allow from all
```

---
**相关资料**:
- [Linux 安装php7](https://www.cnblogs.com/houss/p/11296285.html)
- [centos6.5 源码安装php7](https://segmentfault.com/a/1190000009875949)
- [centos7 编译安装 php7.4](https://www.cnblogs.com/liubaoqing/p/12176017.html)
- [Package ‘oniguruma’, required by ‘virtual:world’, not found](https://www.yanglong.pro/centos8-%e5%ae%89%e8%a3%85-oniguruma-devel/)
- [linux安装php遇到的No package ‘sqlite3’ found，解决方法:yum install sqlite-devel](https://www.cnblogs.com/zhangyouwu/p/12603893.html)
- [CentOS 7编译安装PHP 7.4提示No package ‘libzip’ found或者(libzip >= 0.11)](https://www.jianshu.com/p/d01665bfa4eb)
- [安装libsodium库解决libsodium not found问题](https://www.debugnode.com/ubuntul_ibsodium/)
- [编Installing Libsodium and the PHP extension](https://paragonie.com/book/pecl-libsodium/read/00-intro.md#installing-libsodium)
- [make: *** No targets specified and no makefile found. Stop](https://blog.csdn.net/dannyiscoder/article/details/78455909)
- [configure: error: Package requirements (sqlite3 > 3.7.4) were not met: No package ‘sqlite3’ found](https://www.inbeijing.org/archives/2079)
- [configure: WARNING: unrecognized options: –with-gd](https://www.yanglong.pro/configure-warning-unrecognized-options-with-gd/)
- [Linux下指定pip install和make install安装路径](https://www.cnblogs.com/lenmom/p/10189140.html)
- [phpenv - php多版本配置](https://www.cnblogs.com/RainBol/p/10717036.html)
- [Linux 安装多个php版本并配置](https://www.cnblogs.com/jackzhuo/p/12761035.html)
- [windows - apache 配置多个版本的 php](https://www.cnblogs.com/songlen/p/6613884.html)
- [php的cgi.fix_pathinfo解析](https://blog.csdn.net/b1303110335/article/details/77935245)
- [配置 php-fpm 时出现’/private/etc/php-fpm.conf’: No such file or directory (2)](https://blog.csdn.net/qq_34908844/article/details/77899605)
- [为什么php.ini设置cgi.fix_pathinfo=0](https://blog.csdn.net/weixin_39421014/article/details/80597062)
- [Linux下apache虚拟主机配置多版本php同时运行](https://www.osyunwei.com/archives/10174.html)
- [脚本之家|配置php-fpm参数及配置详解](https://www.jb51.net/article/42716.htm)
- [apache 虚拟目录错误：CustomLog takes two or three arguments, a file name, a custom log format string or format name, and an optional “env=” clause](https://www.rootop.org/pages/109.html)