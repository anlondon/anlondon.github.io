title: vim 特殊字符显示不全
author: anlondon
tags: []
categories:
  - Vim
date: 2021-03-07 20:31:00
---
# 问题

电脑系统 : win7
putty : Release 0.74

最近在搞 vim7.4 的时候，遇到特殊字符显示乱码的问题，刚开始以为是系统输出和插件版本的问题，后来在手机上连接的时候发现手机上却没有问题。

> 电脑上：![](http://anlondon.cn:4000/2021/02/04/vim-%E7%89%B9%E6%AE%8A%E5%AD%97%E7%AC%A6%E6%98%BE%E7%A4%BA%E4%B8%8D/pasted-0.png)
> 
> 手机上：![](http://anlondon.cn:4000/2021/02/04/vim-%E7%89%B9%E6%AE%8A%E5%AD%97%E7%AC%A6%E6%98%BE%E7%A4%BA%E4%B8%8D/pasted-1.png)

# 解决

1. 设置输出编码
 在 ~/.vimrc 中添加以下代码，设置输出编码
 具体的见 [vim 编码设置讲解](https://blog.csdn.net/x13945/article/details/15020307)
 ```shell
 "设置编码自动识别
 set termencoding=utf-8
 set fileencoding=chinese set fileencodings=ucs-bom, utf-8, chinese set langmenu=zh_CN. utf-8
 ```
2. 切换字体；因为 putty 软件默认的字体是 `courier New` ，而该字体win7上没有，所以切换为 `新宋体` 即可。
> 注意：字符涵盖最多的是 Unicode 的，它包含了全球所有语言的文字和特殊字符，导致 Unicode 字库很庞大，一般字体并不会完全包含，只会选取常用的特殊字符编进字体软件中。
> 初始设置：
> ![](http://anlondon.cn:4000/2021/02/04/vim-%E7%89%B9%E6%AE%8A%E5%AD%97%E7%AC%A6%E6%98%BE%E7%A4%BA%E4%B8%8D/pasted-2.png)

 手动修改为 新宋体 ，并调整光标样式：
 ![来自anlondon博客](http://anlondon.cn:4000/2021/02/04/vim-%E7%89%B9%E6%AE%8A%E5%AD%97%E7%AC%A6%E6%98%BE%E7%A4%BA%E4%B8%8D/pasted-3.png)
 > 选择 粗体，不然字体很细
 附上中文翻译
 ![](http://anlondon.cn:4000/2021/02/04/vim-%E7%89%B9%E6%AE%8A%E5%AD%97%E7%AC%A6%E6%98%BE%E7%A4%BA%E4%B8%8D/pasted-4.png)

最后附上调整后的样式
![](http://anlondon.cn:4000/2021/02/04/vim-%E7%89%B9%E6%AE%8A%E5%AD%97%E7%AC%A6%E6%98%BE%E7%A4%BA%E4%B8%8D/pasted-5.png)

> 当然并不是所有的特殊字符都能正常显示，这个就只能手动调整了

最后，如果是愿意折腾的小伙伴，可以看看相关资料的第二个链接，里面也有人遇到相似的问题，也有大佬提出了一些建议和办法。

---
**相关资料**：
- [vim 编码设置讲解](https://blog.csdn.net/x13945/article/details/15020307)
- [如何配置PuTTY显示这些字符？](https://superuser.com/questions/393834/how-to-configure-putty-to-display-these-characters#)