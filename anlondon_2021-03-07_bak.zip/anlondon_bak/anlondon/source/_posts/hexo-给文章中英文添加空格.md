title: hexo 给文章中英文添加空格
author: anlondon
tags: []
categories:
  - Hexo
date: 2021-03-07 18:21:00
---
**来源**: [振伟普拉斯 | Hexo 给文章中英文添加空格](https://zhangzw.com/posts/20190830.html) 

![](https://zhangzw.com/images/banner/30.jpg)

在使用Hexo写文章时，由于写的大都是些技术类的文章，中英文字符经常交错在一起，对于强迫症的我来说看起来着实不舒服了。

好在 GitHub 上什么大神都有，还真有人开发了给中英文添加空格的工具：[https://github.com/vinta/pangu.js](https://github.com/vinta/pangu.js)

>    　　為什麼你們就是不能加個空格呢？
>    　　如果你跟我一樣，每次看到網頁上的中文字和英文、數字、符號擠在一塊，就會坐立難安，忍不住想在它們之間加個空格。這個外掛（支援 Chrome 和 Firefox）正是你在網路世界走跳所需要的東西，它會自動替你在網頁中所有的中文字和半形的英文、數字、符號之間插入空白。
>
>    　　漢學家稱這個空白字元為「盤古之白」，因為它劈開了全形字和半形字之間的混沌。另有研究顯示，打字的時候不喜歡在中文和英文之間加空格的人，感情路都走得很辛苦，有七成的比例會在 34 歲的時候跟自己不愛的人結婚，而其餘三成的人最後只能把遺產留給自己的貓。畢竟愛情跟書寫都需要適時地留白。

在 Hexo 中使用也很简单，npm 安装一下就可以了：
`npm install hexo-pangu-spacing --save`

然后重新 hexo g 看修改后的效果。
### 20191201，纠正

上面这个插件有些问题，在代码中也会加入空格，代码中应该是不需要的。

又找到另一个插件，试了下没问题：[https://github.com/hexojs/hexo-filter-auto-spacing](https://github.com/hexojs/hexo-filter-auto-spacing)

### 其他问题(anlondon)

- `hexo-pangu-spacing`会导致 \*\***加粗**\*\* 失效
- `hexo-filter-auto-spacing`会导致脚注插件不能正常运行

**相关文章**
- [Hexo NexT 主题添加自定义字体（基于 7.1.0 版本）](https://zhangzw.com/posts/20191110.html)
- [Hexo 使用 hexo-neat 插件压缩页面资源](https://zhangzw.com/posts/20190831.html)
- [Hexo NexT 主题集成 utterance 评论系统](https://zhangzw.com/posts/20190720.html)
- [Hexo Next 主题自定义样式](https://zhangzw.com/posts/20190701.html)
