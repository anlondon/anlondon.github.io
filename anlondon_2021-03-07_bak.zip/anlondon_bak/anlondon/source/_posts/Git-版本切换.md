title: Git 版本切换
author: anlondon
tags: []
categories:
  - Git
date: 2021-03-07 22:00:00
---
### 主要内容：
> 1） HEAD指向的版本就是当前版本，因此，Git允许我们在版本的历史之间穿梭，使用命令`git reset --hard commit_id`。
> 2）用`git log`可以查看提交历史，可以查询到我们要返回版本的ID。
> 3）版本回退之后，需要再次回到会退前，可以用`git reflog`查看命令历史，可以查看到每次命令的记录，里面会有我们需要的版本ID。

### 一： 按次回退

HEAD表示当前版本，回退到上一个版本用：
`git reset --hard HEAD^`

回退到上上一个版本，使用：
`git reset --hard HEAD^^`

回退到20个版本之前，使用：
`git reset --hard HEAD~20`

### 二：指定commit_id

有时候，提交的东西多了
`git log` 查看记录
`git reflog` 查看历史记录

回退到指定版本： 
`$ git reset --hard 52602b0`

> 只需要输入7位 ID 即可

---
**相关资料**：
- [Git 版本前后切换|博客园|codingOrange](https://www.cnblogs.com/zhangguicheng/articles/12080897.html)