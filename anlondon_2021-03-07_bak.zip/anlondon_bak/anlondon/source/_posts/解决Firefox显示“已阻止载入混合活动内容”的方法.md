title: 解决Firefox显示“已阻止载入混合活动内容”的方法
author: anlondon
tags: []
categories:
  - 杂谈
date: 2021-03-07 22:05:00
---
> 来源：[解决Firefox显示“已阻止载入混合活动内容”的方法](https://www.cnblogs.com/jeacy/p/8971170.html)
> 作者：[Jacey](https://www.cnblogs.com/jeacy/)

今天把项目放到服务器上了，调试的时候出现“已阻止载入混合活动内容……”的报错：
![一座浮岛](/2021/03/07/解决Firefox显示“已阻止载入混合活动内容”的方/pasted-0.png)

**解决方法如下：**
- 方法1：让Firefox暂时不阻止

  打开新标签页，在地址栏输入 about:config，进入配置页面。
  搜索 security.mixed_content.block_active_content，将true改为false。
  
![一座浮岛](/2021/03/07/解决Firefox显示“已阻止载入混合活动内容”的方/pasted-1.png)

- 方法2：避免在HTTPS页面中包含HTTP的内容。
 
 第1种方法很不现实，因为我们不能要求所有用户去改这项配置。
 我们可以看看是不是从https提交内容到http的原因，如果是的话，把请求的URL改成https的就可以了。

 经排查，发现访问URL的时候确实是http的，将其改成https，不再报错了。
 
![一座浮岛](/2021/03/07/解决Firefox显示“已阻止载入混合活动内容”的方/pasted-2.png)