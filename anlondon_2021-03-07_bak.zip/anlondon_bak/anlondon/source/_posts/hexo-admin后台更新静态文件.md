title: hexo-admin后台更新静态文件
author: anlondon
tags: []
categories:
  - Hexo
date: 2021-03-07 11:06:00
---
#### 建立.sh文件

因为我服务器为linux，所以这里就以linux下作为演示

```shell
# 1.你的博客根目录下，新建一个存放shell脚本的目录
$ mkdir ./script
$ vim ./script/hexo-g.sh

# 2.按 i 进入编辑
# 输入 
#!/bin/bash <-表示执行下面命令的程序
hexo clean && hexo g

# 3.ESC退出编辑模式，输入 :wq 保存退出
# 输出文件内容
$ cat ./script/hexo-g.sh
#!/bin/bash
hexo clean && hexo g

# 4.给文件执行权限
$ chmod +x ./script/hexo-g.sh
```

#### 在_config.yml添加执行command

```shell
$ vim _config.yml

# 输入以下内容 
admin:
   username: xxxxx
   password_hash: XXXXXXXX
   secret: XXXXXX
   deployCommand: './script/hexo-g.sh'
```

#### 使用

写完博客，点击即可

来自anlondon博客

因为我不需要推送到git,所以没配置git和hexo d，如有需要可以自行配置

#### 可能的错误

页面报错：

来自anlondon博客

命令行报错：
```shell
res Error: spawn ./script/hexo-g.sh EACCE
    at Process.ChildProcess._handle.onexit (internal/child_process.js:269:19)
    at onErrorNT (internal/child_process.js:465:16)
    at processTicksAndRejections (internal/process/task_queues.js:80:21) {
  errno: -13,
  code: 'EACCES',
  syscall: 'spawn ./script/hexo-g.sh',
  path: './script/hexo-g.sh',
  spawnargs: [ '' ]
} { stdout: '', stderr: '' }
```

原因：是因为我linux没有安装expect，而spawn是expect的功能之一，`yum install expect`即可解决

更多hexo-admin的问答见[hexo-admin 开发者问答](https://github.com/jaredly/hexo-admin/issues?page=2&q=is:issue+is:open)