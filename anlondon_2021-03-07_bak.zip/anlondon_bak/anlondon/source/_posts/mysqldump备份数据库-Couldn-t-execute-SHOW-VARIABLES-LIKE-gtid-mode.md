title: mysqldump备份数据库 Couldn't execute 'SHOW VARIABLES LIKE 'gtid\_mode''
author: anlondon
tags: []
categories:
  - MySql
date: 2021-03-07 22:02:00
---
## 错误

`mysqldump: Couldn’t execute ‘SHOW VARIABLES LIKE ‘gtid_mode’’: Table ‘performance_schema.session_variables’ doesn’t exist (1146)`

## 原因

这是mysql升级的结果；因为我本地切换过MySQL版本而导致的错误

## 解决

- win
 ```shell
 #更新
 $ mysql_upgrade -u root -p --force
 #需要停止进程
 $ net stop mysql
 #再次开启
 $ net start mysql
 ```
 
- linux
 ```shell
 $ mysql_upgrade -u root -p --force
 $ systemctl restart mysqld
 ```
---
**相关资料**：
- [mysqldump备份数据库出现（Couldn’t execute ‘SHOW VARIABLES LIKE ‘gtid_mode’’）错误解决办法](https://www.lonery.com/article-view-118.html)
- [mysqldump: Couldn’t execute ‘SHOW VARIABLES LIKE ‘gtid_mode’’: Table ‘performance_schema.session_v](https://blog.csdn.net/qq_31725371/article/details/101538339)