title: NERD Commenter
author: anlondon
tags: []
categories:
  - Vim
date: 2021-03-07 20:40:00
---
> 转载：[vim插件之 NERD Commenter](https://www.cnblogs.com/yzsatcnblogs/p/4245078.html)
> 作者：[_扬帆起航](https://home.cnblogs.com/u/yzsatcnblogs/)

##### 【插件使用】
注：这里已经将”"改为”,”

简单介绍下NERD Commenter的常用键绑定，以C/C++文件为例，详析的使用方法，请:h NERDCommenter。在Normal或者Visual 模式下：

经测试，想要下面的命令生效，需要将光标置于每行的空白处，也就是说光标上不能有字符。

> \ca 在可选的注释方式之间切换，比如C/C++ 的块注释/* */和行注释//
> \cc 注释当前行
> \c 切换注释/非注释状态
> \cs 以”性感”的方式注释
> \cA 在当前行尾添加注释符，并进入Insert模式
> \cu 取消注释
> Normal模式下，几乎所有命令前面都可以指定行数。 比如 输入 6,cs 的意思就是以性感方式注释光标所在行开始6行代码
> Visual模式下执行命令，会对选中的特定区块进行注释/反注释

此外，其它的nerdcommenter命令可以在NORMAL模式下输入命令 :map 看到。 下面是我的截图

![](/2021/03/07/NERD-Commente/pasted-0.png)

**注：再次说明，各命令前缀是可以自己设置的，通常是逗号’,’或者’\’.**

**注：看名字可以知道，它和The NERD Tree同属一个作者**
A mind needs books like a sword needs a whetstone.

##### 【插件介绍】
这是一款用于快速高效注释代码的插件

使用这款插件，你可以对多种文件类型的文件进行不同方式地、快速地注释。这对使用Vim来写代码或者修改配置文件的同学来说，无疑是提升效率和快感的一件利器。

##### 【插件安装】
我总结了三种安装方法

**(1). 在bundle中安装**

　会使用Bundle管理vim插件的朋友都知道，只要加入以下代码，即可。
  `Bundle 'The-NERD-Commenter'`
  或者
`Bundle`
`'scrooloose/nerdcommenter'`

**（2）直接下载**
你可以到[这里来下载](http://anlondon.cn:4000/admin/www.vim.org/scripts/script.php?script_id=1218)这个插件，将压缩包里面的doc/和plugin/文件夹丢到~/.vim/下面就是安装了。为了可以使用其帮助文档，你还需要在Vim中执行:helptags ~/.vim/doc/来注册。

##### 【插件配置】

如果想把默认的leader从“\”改为“,”， 则在在配置文件.vimrc中，加入下面一行
`let mapleader=","`