title: pm2项目启动成功，但pm2 list又显示errored的问题
author: anlondon
tags: []
categories:
  - pm2
date: 2021-03-07 11:16:00
---


- 首先先判断入口js文件app.js在node上是否能正确运行，确定是否缺少依赖。如若缺少则安装对应的依赖再进行pm2管理。

- 如若node能正常运行，pm2也能正常启动，但在使用pm2 list命令查看列表时项目出现errored，则尝试以下两行命令

来自anlondon博客

```shell
ps aux | grep pm2 (查看pm2进程占用情况)
kill -9  14360 (这个数值要依据你上面命令返回的进程id进行填写)
```

杀死pm2进程之后再次重启项目，解决问题。

- 也可以通过`pm2 show id`来查看详细的错误信息，进行对应的处理
