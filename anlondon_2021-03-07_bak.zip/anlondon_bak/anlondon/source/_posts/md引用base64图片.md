title: md引用base64图片
author: anlodon
tags: []
categories:
  - MarkDown
date: 2021-03-07 11:03:00
---

# markdown 引用base64图片

##### 使用
 - 声明
 `[image_name]:data:image/png;base64,..`
 
 - 调用
 `![图片描述][image_name]`
 > 注意：图片越大，base64代码越多，加载也就会越久
前端规范中，一般在2k及以下的图片才能使用 Base64

##### 图片转 Base64 的网站
[站长工具](http://tool.chinaz.com/tools/imgtobase/)

**注意！**
hexo-admin 测试 Base64 时，会出现加载很慢的情况，是因为 hexo-admin 会一次加载全部的文章数据，而过多的 Base64 会导致数据包过大影响页面加载速度。