title: o盘隐藏文件
author: anlondon
tags: []
categories:
  - 杂谈
date: 2021-03-07 21:47:00
---
- 新建文本，输入以下内容，并修改文件后缀为cmd
```cmd
@ECHO OFF
MD E:\RECYCLED\UDrives.{25336920-03F9-11CF-8FD0-00AA00686F13}>NUL
IF EXIST O:\NUL GOTO DELETE
SUBST O: E:\RECYCLED\UDrives.{25336920-03F9-11CF-8FD0-00AA00686F13}
START
O:\
GOTO END
:delete
SUBST /D O:
:END
```
双击cmd运行，会自动在 **E盘** 新建一个 **RECYCLED** 文件夹。而系统会生成一个o盘，存放完东西后，再次双击，该盘就会消失。

> 在xp下，该文件夹会自动变成回收站，但是win10不会，如果是win10，想要生效则要设置 desktop.ini。

右键 RECYCLED 文件夹->属性->高级，**取消勾选**\[除了 文件属性外，还允许索弓此文件夹中文件的内容\]

使用**win自带的搜索工具**就不能查找到该文件夹内的文件，确认之后，勾选属性中的**只读**与**隐藏**。
> 但是其他更强大的搜索软件能搜索到，毕竟该方法**只是隐藏，没有加密**

- RECYCLED 属性设置

 win10中，文件夹名并不会影响到文件夹属性，所以需要手动设置文件夹属性

 在 RECYCLED 文件夹里新建**desktop.ini**，写入
 ```shell
 [.ShellClassInfo]
 CLSID={645FF040-5081-101B-9F08-00AA002F954E}
 ```
 
 `{645FF040-5081-101B-9F08-00AA002F954E}`为回收站
保存后，重开文件夹就成了回收站。无法打开,但是右键属性并且因为属于系统性文件夹,只开启 **文件夹选项**中的 \[显示隐藏文件\] 也不能查看

- 不过可以通过cmd/rar查看
 cmd：
 ```shell
 #进入该文件夹
 $ cd RECYCLED
 #查看文件
 $ dir
 #只显示隐藏文件
 $ dir /a:h
 	#使用记事本 编辑desktop.ini
 	$ notepad desktop.ini
 ```