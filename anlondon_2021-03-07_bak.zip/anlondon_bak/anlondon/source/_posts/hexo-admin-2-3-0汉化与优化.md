title: hexo-admin@2.3.0汉化与优化
author: anlondon
tags: []
categories:
  - Hexo
date: 2021-03-07 11:54:00
---
#### 参考
[hexo-admin汉化补丁](https://blog.csdn.net/nineya_com/article/details/103384546)

#### 与原版的区别
1. 进行了汉化
2. 让图片管理更方便，每篇文章都有对应的图片文件夹。
3. 添加了自动保存和部署的功能

#### 问题
1. 过于频繁的自动提交，每次键入停顿时间超过一秒，就会自动上传罪最新的文本，并自动更新静态文件；文本过大时，这会影响到使用，也会加重服务器的负担。