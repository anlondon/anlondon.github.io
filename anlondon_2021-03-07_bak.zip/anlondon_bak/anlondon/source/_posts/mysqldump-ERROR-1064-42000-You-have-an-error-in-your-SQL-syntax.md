title: 'mysqldump ERROR 1064 (42000): You have an error in your SQL syntax'
author: anlondon
tags: []
categories:
  - MySql
date: 2021-03-07 22:15:00
---
> 来源[mysqldump备份数据库提示ERROR 1064 (42000): You have an error in your SQL syntax](https://blog.csdn.net/sunsineq/article/details/105275050)
> 作者：sunsineq

```shell
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that
corresponds to your MySQL server version for the right syntax to use near 'mysql
 -v' at line 1
```
在dos下备份数据库的时候提示上面的错误信息

通过查资料知道，不需要登录mysql,只需要在命令行下切换到mysql\bin目录，使用备份命令mysqldump即可

```shell
d:\phpStudy\MySQL\bin>mysqldump -uroot -proot testphp >d:\testphp.sql
   
d:\phpStudy\MySQL\bin>
```